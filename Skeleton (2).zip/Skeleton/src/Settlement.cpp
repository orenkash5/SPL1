#include "Settlement.h"
#include <iostream>
using namespace std;

Settlement::Settlement(const string &name, SettlementType type) : name(name), type(type) {}

const string& Settlement::getName() const
{
    return name;
}
SettlementType Settlement::getType() const
{
    return type;
}
const string Settlement::toString() const
{
    return "Settlement Name: " + name;
}
const int Settlement::constructionLimit() const
{
    int i;
    switch (type)
    {
    case SettlementType::VILLAGE:
        i = 1;
        break;
    case SettlementType::CITY:
        i = 2;
        break;
    case SettlementType::METROPOLIS:
        i = 3;
        break;
    }
    return i;
};