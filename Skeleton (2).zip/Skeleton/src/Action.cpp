#include "Action.h"
#include "iostream"
#include "Simulation.h"

using namespace std;

extern Simulation* backup;

enum class SettlementType;
enum class FacilityCategory;

enum class ActionStatus{
    COMPLETED, ERROR
};


class BaseAction{
    public:
        BaseAction(){}
        ActionStatus getStatus() const{
            return status;
        }
        virtual void act(Simulation& simulation)=0;
        virtual const string toString() const=0;
        virtual BaseAction* clone() const = 0;
        virtual ~BaseAction() = default;

    protected:
        void complete(){
            status = ActionStatus::COMPLETED;
        }
        void error(string errorMsg){
            status = ActionStatus::ERROR;
            this->errorMsg = errorMsg;
            cerr << "Error: " << errorMsg << endl;
        }
        const string &getErrorMsg() const{
            return errorMsg;
        }

    private:
        string errorMsg;
        ActionStatus status;
};

class SimulateStep : public BaseAction {

    public:
        SimulateStep(const int numOfSteps) : numOfSteps(numOfSteps){}
        void act(Simulation &simulation) override{
            for(int i=0; i<numOfSteps; i++){
                simulation.step();
            }
            this->complete();
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "SimulateStep " + to_string(numOfSteps) + " " + statusString;
        }

        SimulateStep *clone() const override{
            SimulateStep* s = new SimulateStep(numOfSteps);
            return s;
        }
    private:
        const int numOfSteps;
};
class AddPlan : public BaseAction {
    public:
        AddPlan(const string &settlementName, const string &selectionPolicy): settlementName(settlementName), selectionPolicy(selectionPolicy){}
        void act(Simulation &simulation) override{
            if(simulation.isSettlementExists(settlementName) && simulation.isSelectionPolicyExists(selectionPolicy))
            {
                SelectionPolicy* sp;
                if(selectionPolicy == "nve"){
                    sp = new NaiveSelection();
                }
                else
                    if(selectionPolicy == "bal"){
                        sp = new BalancedSelection(0, 0, 0);
                    }
                else   
                    if(selectionPolicy == "eco"){
                        sp = new EconomySelection();
                    }
                Settlement* s = simulation.getSettlement(settlementName);
                simulation.addPlan(s, sp);
                this->complete();
            }
            else
            {
                cerr << "Cannot create this plan" << endl;
            }
                
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "AddPlan: " + settlementName + " " + selectionPolicy + " " + statusString;


        }
        AddPlan *clone() const override{
            AddPlan* a = new AddPlan(settlementName, selectionPolicy);
            return a;
        }
    private:
        const string settlementName;
        const string selectionPolicy;
};

class AddSettlement : public BaseAction {
    public:
        AddSettlement(const string &settlementName,SettlementType settlementType): settlementName(settlementName), settlementType(settlementType){}
        void act(Simulation &simulation) override{
            if(!simulation.isSettlementExists(settlementName))
            {
                Settlement* s = new Settlement(settlementName, settlementType);
                simulation.addSettlement(s);
                this->complete();
            }
            else
            {
                error("Settlement already exists");
            }
        }
        
        AddSettlement *clone() const override{
            AddSettlement* a = new AddSettlement(settlementName, settlementType);
            return a;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            string settlementTypeString;
            switch(this->settlementType){
                case SettlementType::VILLAGE:
                    settlementTypeString = "VILLAGE";
                    break;
                case SettlementType::CITY:
                    settlementTypeString = "CITY";
                    break;
                case SettlementType::METROPOLIS:
                    settlementTypeString = "METROPOLIS";
                    break;
            }
            return "AddSettlement: " + settlementName + "" + settlementTypeString + " " + statusString;
        }
    private:
        const string settlementName;
        const SettlementType settlementType;
};

class AddFacility : public BaseAction {
    public:
        AddFacility(const string &facilityName, const FacilityCategory facilityCategory, const int price, const int lifeQualityScore, const int economyScore, const int environmentScore) : facilityName(facilityName), facilityCategory(facilityCategory), price(price), lifeQualityScore(lifeQualityScore), economyScore(economyScore), environmentScore(environmentScore){}
        void act(Simulation &simulation) override{
            if(!simulation.isFacilityExists(facilityName))
            {
                FacilityType f(facilityName, facilityCategory, price, lifeQualityScore, economyScore, environmentScore);
                simulation.addFacility(f);
                this->complete();
            }
            else
            {
                error("Facility already exists");
            }

        }
        AddFacility *clone() const override{
            AddFacility* a = new AddFacility(facilityName, facilityCategory, price, lifeQualityScore, economyScore, environmentScore);
            return a;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "AddFacility " + facilityName + " " + to_string(price) + " " + to_string(lifeQualityScore) + " " + to_string(economyScore) + " " + to_string(environmentScore) + " " + statusString;
        }
    private:
        const string facilityName;
        const FacilityCategory facilityCategory;
        const int price;
        const int lifeQualityScore;
        const int economyScore;
        const int environmentScore;

};

class PrintPlanStatus: public BaseAction {
    public:
        PrintPlanStatus(int planId): planId(planId){}
        void act(Simulation &simulation) override{
            if(simulation.isPlanExists(planId))
            {
                Plan p = simulation.getPlan(planId);
                p.printStatus();
                this->complete();
            }
            else{
                error("Plan does not exist");
            }
        }
        PrintPlanStatus *clone() const override{
            PrintPlanStatus* p = new PrintPlanStatus(planId);
            return p;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "PrintPlanStatus " + to_string(planId) + " " + statusString;
        }
    private:
        const int planId;
};

class ChangePlanPolicy : public BaseAction {
    public:
        ChangePlanPolicy(const int planId, const string &newPolicy): planId(planId), newPolicy(newPolicy){}
        void act(Simulation &simulation) override{
            if(simulation.isPlanExists(planId)){
                Plan p = simulation.getPlan(planId);
                SelectionPolicy* current = p.getSelectionPolicy();
                if(p.toString()!=newPolicy){
                    SelectionPolicy* newSelectionPolicy;
                    if(newPolicy=="nve"){
                        newSelectionPolicy = new NaiveSelection();
                    }
                    else
                        if(newPolicy=="bal"){
                            newSelectionPolicy = new BalancedSelection(0, 0, 0);
                        }
                    else
                        if(newPolicy=="eco"){
                            newSelectionPolicy = new EconomySelection();
                        }
                    else{
                        if(newPolicy=="env"){
                            newSelectionPolicy = new SustainabilitySelection();
                        }
                    }
                    p.setSelectionPolicy(newSelectionPolicy);
                    this->complete();
                }
                else{
                    error("Cannot change selection policy”");
                }
            }
            else{
                error("Cannot change selection policy”");
            }
        }

        ChangePlanPolicy *clone() const override{
            ChangePlanPolicy* c = new ChangePlanPolicy(planId, newPolicy);
            return c;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "ChangePlanPolicy " + to_string(planId) + " " + newPolicy + " " + statusString;
        }
    private:
        const int planId;
        const string newPolicy;
};

class PrintActionsLog : public BaseAction {
    public:
        PrintActionsLog(){}
        void act(Simulation &simulation) override{
            for (BaseAction* a : simulation.getActionsLog()){
                cout << a->toString() << endl;
            }
            this->complete();
        }
        PrintActionsLog *clone() const override{
            PrintActionsLog* p = new PrintActionsLog();
            return p;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "PrintActionsLog " + statusString;
        }
    private:
};

class Close : public BaseAction {
    public:
        Close(){}
        void act(Simulation &simulation) override{
            simulation.close();
            this->complete();
        }
        Close *clone() const override{
            Close* c = new Close();
            return c;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "Close " + statusString;
        }
    private:
};

class BackupSimulation : public BaseAction {
    public:
        BackupSimulation(){}

        void act(Simulation &simulation) override{
            if (backup!=nullptr){
                delete backup; //need to change to rule of 5
            }
            backup= new Simulation(simulation); 
            this->complete();
        }
        BackupSimulation *clone() const override{
            BackupSimulation* b = new BackupSimulation();
            return b;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "Backup " + statusString;
        }
    private:
};

class RestoreSimulation : public BaseAction {
    public:
        RestoreSimulation(){}
        void act(Simulation &simulation) override{
            if (backup!=nullptr){

                this->complete();

            }
            else { error("No backup available");
            }
        }
        RestoreSimulation *clone() const override{
            RestoreSimulation* r = new RestoreSimulation();
            return r;
        }
        const string toString() const override{
            string statusString;
            switch(getStatus()){
                case ActionStatus::COMPLETED:
                    statusString = "COMPLETED";
                    break;
                case ActionStatus::ERROR:
                    statusString = "ERROR";
                    break;
            }
            return "RestoreSimulation " + statusString;
        }
    private:
};
