#include "Settlement.h"
#include <iostream>
using namespace std;

enum class SettlementType {
    VILLAGE,
    CITY,
    METROPOLIS,
};

class Settlement{
    public:
        Settlement(const string &name, SettlementType type) : name(name), type(type){}
        const string &getName() const{
            return name;
        }
        SettlementType getType() const{
            return type;
        }
        const string toString() const{
            return "Settlement Name: " + name;
        }
        const int constructionLimit() const{
            int i;
            switch(type){
                case SettlementType::VILLAGE:
                     i=1;
                     break;
                case SettlementType::CITY:
                     i=2;
                     break;
                case SettlementType:: METROPOLIS:
                     i=3;
                     break;      
            }
            return i;
        }
        
    private:
        const string name;
        SettlementType type;


};