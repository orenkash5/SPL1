#include "Simulation.h"
#include "Auxiliary.h"
#include <algorithm>
#include <fstream>
#include <iostream>
#include "Plan.h"
using namespace std;

class Simulation {
    public:
        Simulation(const string &configFilePath){
            isRunning = true;
            planCounter = 0;
            ifstream file(configFilePath);
            string line;
            if(file.is_open()){
                while(getline(file, line)){
                    vector<string> arguments = Auxiliary::parseArguments(line);
                    SettlementType st;
                    // we need to add to actionslog
                    if(arguments[0]=="settlement")
                    {
                        if(arguments[2]== "0"){
                            st = SettlementType::VILLAGE;
                        }
                        if(arguments[2]== "1"){
                            st = SettlementType::CITY;
                        }
                        if(arguments[2]== "2"){
                            st = SettlementType::METROPOLIS;
                        }
                        Settlement* s = new Settlement(arguments[1], st);
                        addSettlement(s);
                    }
                    if(arguments[0]=="facility")
                    {
                        FacilityCategory fc;
                        if(arguments[2] == "0"){
                            fc = FacilityCategory::LIFE_QUALITY;
                        }
                        if(arguments[2] == "1"){
                            fc = FacilityCategory::ECONOMY;
                        }
                        if(arguments[2] == "2"){
                            fc = FacilityCategory::ENVIRONMENT;
                        }
                        FacilityType ft(arguments[1], fc, stoi(arguments[3]), stoi(arguments[4]), stoi(arguments[5]), stoi(arguments[6]));
                        addFacility(ft);
                    }
                    if(arguments[0]=="plan")
                    {
                                            
                    }
                    

                }

            }


        }
        void start(){
            cout << "The simulation started" << endl;
        }
        void addPlan(const Settlement *settlement, SelectionPolicy *selectionPolicy){
            Plan* p= new Plan(planCounter, *settlement, selectionPolicy, facilitiesOptions);
            planCounter++;
            plans.push_back(*p);
        }
        bool isPlanExists(const int planID){
            for(int i=0; i<plans.size(); i++){
                if(plans[i].getPlanID()==planID){
                    return true;
                }
            }
            return false;
        }
        void addAction(BaseAction *action){
            actionsLog.push_back(action);
        }
        bool addSettlement(Settlement *settlement){
            if(!isSettlementExists(settlement->getName())){
                settlements.push_back(settlement);
                return true;
            }
            
        else {
            cerr << "Settlement already exists" << endl;
            return false;
        }
           
        }
        bool addFacility(FacilityType facility){
            if(!isFacilityExists(facility.getName())){
                facilitiesOptions.push_back(facility);
                return true;
            }
            else{
                cerr << "Facility already exists" << endl;
                return false;
            }
        }
        bool isSelectionPolicyExists(const string &selectionPolicy){
            if(selectionPolicy=="nve" || selectionPolicy=="bal" || selectionPolicy=="eco"){
                return true;
            }
            else{
                return false;
            }
        }
        bool isFacilityExists(const string &facilityName){
            for(int i=0; i<facilitiesOptions.size(); i++){
                if(facilitiesOptions[i].getName()==facilityName){
                    return true;
                }
            }
            return false;
        }
        bool isSettlementExists(const string &settlementName){
            for(int i=0; i<settlements.size(); i++){
                if(settlements[i]->getName()==settlementName){
                    return true;
                }
            }
            return false;
        }
        Settlement *getSettlement(const string &settlementName){
            for(int i=0; i<settlements.size(); i++){
                if(settlements[i]->getName()==settlementName){
                    return settlements[i];
                }
            }
        }
        Plan &getPlan(const int planID){
            for(int i=0; i<plans.size(); i++){
                if(plans[i].getPlanID()==planID){
                    return plans[i];
                }
            }
        }
        vector<BaseAction*> getActionsLog() const {
            return actionsLog;
        }
        void step(){
            for(Plan p : plans){
                p.step();  
            }
        }
        void close(){
            for(Plan p : plans){
                cout << p.toString() << endl;
            }
            isRunning = false;
        }
        
        void open();

    private:
        bool isRunning;
        int planCounter; //For assigning unique plan IDs
        vector<BaseAction*> actionsLog;
        vector<Plan> plans;
        vector<Settlement*> settlements;
        vector<FacilityType> facilitiesOptions;
};