#include "Simulation.h"
#include "Auxiliary.h"
#include "Action.h"
#include <algorithm>
#include <fstream>
#include <iostream>
#include "Plan.h"
using namespace std;

Simulation::Simulation(const string &configFilePath) : isRunning(false), planCounter(0), actionsLog(), plans(), settlements(), facilitiesOptions()
{
    ifstream file(configFilePath);
    string line;
    if (file.is_open())
    {
        while (getline(file, line))
        {
            vector<string> arguments = Auxiliary::parseArguments(line);
            SettlementType st;
            if (arguments[0] == "plan")
            {
                AddPlan *ap = new AddPlan(arguments[1], arguments[2]);
                ap->act(*this);
            }
            if (arguments[0] == "settlement")
            {
                if (arguments[2] == "0")
                {
                    st = SettlementType::VILLAGE;
                }
                if (arguments[2] == "1")
                {
                    st = SettlementType::CITY;
                }
                if (arguments[2] == "2")
                {
                    st = SettlementType::METROPOLIS;
                }
                AddSettlement *as = new AddSettlement(arguments[1], st);
                as->act(*this);
            }
            if (arguments[0] == "facility")
            {
                FacilityCategory fc;
                if (arguments[2] == "0")
                {
                    fc = FacilityCategory::LIFE_QUALITY;
                }
                if (arguments[2] == "1")
                {
                    fc = FacilityCategory::ECONOMY;
                }
                if (arguments[2] == "2")
                {
                    fc = FacilityCategory::ENVIRONMENT;
                }
                AddFacility *af = new AddFacility(arguments[1], fc, stoi(arguments[3]), stoi(arguments[4]), stoi(arguments[5]), stoi(arguments[6]));
                af->act(*this);
            }
        }
    }
}
Simulation::Simulation(const Simulation &other) : isRunning(other.isRunning), planCounter(other.planCounter), actionsLog(), plans(other.plans), settlements(), facilitiesOptions(other.facilitiesOptions)
{
    for (BaseAction *b : other.actionsLog)
    {
        actionsLog.push_back(b->clone());
    }
    for (Settlement *s : other.settlements)
    {
        settlements.push_back(new Settlement(*s));
    }
}
Simulation &Simulation::operator=(const Simulation &other)
{
    if (this != &other)
    {
        clear();
        isRunning = other.isRunning;
        planCounter = other.planCounter;
        for (Plan p : other.plans)
        {

            plans.push_back(*(new Plan(p)));
        }
        for (FacilityType f : other.facilitiesOptions)
        {
            facilitiesOptions.push_back(f);
        }
        for (BaseAction *b : other.actionsLog)
        {
            actionsLog.push_back(b->clone());
        }
        for (Settlement *s : other.settlements)
        {
            settlements.push_back(new Settlement(*s));
        }
    }
    return *this;
}
void Simulation::clear()
{
    isRunning = false;
    planCounter = 0;
    for (BaseAction *b : actionsLog)
    {
        if (b != nullptr)
            delete b;
    }
    actionsLog.clear();
    plans.clear();
    for (Settlement *s : settlements)
    {
        if (s != nullptr)
            delete s;
    }
    settlements.clear();
    facilitiesOptions.clear();
}
Simulation::~Simulation()
{
    clear();
}

Simulation::Simulation(Simulation &&other) : isRunning(other.isRunning),
                                             planCounter(other.planCounter),
                                             actionsLog(move(other.actionsLog)),
                                             plans(other.plans),
                                             settlements(move(other.settlements)),
                                             facilitiesOptions(other.facilitiesOptions)
{
    other.isRunning = false;
    other.planCounter = 0;
    other.actionsLog.clear();
    other.settlements.clear();
}

Simulation &Simulation::operator=(Simulation &&other)
{
    if (this != &other)
    {
        clear();
        isRunning = other.isRunning;
        planCounter = other.planCounter;
        actionsLog = move(other.actionsLog);
        for (Plan p : other.plans)
        {
            plans.push_back(*(new Plan(p)));
        }
        settlements = move(other.settlements);
        for (FacilityType f : other.facilitiesOptions)
        {
            facilitiesOptions.push_back(f);
        }

        other.isRunning = false;
        other.planCounter = 0;
        other.actionsLog.clear();
        other.settlements.clear();
    }
    return *this;
}

void Simulation::start()
{

    cout << "The simulation has started" << endl;
    open();
    while (isRunning)
    {
        string line;
        cin >> line;
        vector<string> arguments = Auxiliary::parseArguments(line);
        if (arguments[0] == "step")
        {
            SimulateStep *ss = new SimulateStep(stoi(arguments[1]));
            ss->act(*this);
            actionsLog.push_back(ss);
        }
        if (arguments[0] == "planStatus")
        {
            PrintPlanStatus *pps = new PrintPlanStatus(stoi(arguments[1]));
            pps->act(*this);
            actionsLog.push_back(pps);
        }
        if (arguments[0] == "changePolicy")
        {
            ChangePlanPolicy *cpp = new ChangePlanPolicy(stoi(arguments[1]), arguments[2]);
            cpp->act(*this);
            actionsLog.push_back(cpp);
        }
        if (arguments[0] == "log")
        {
            PrintActionsLog *pal = new PrintActionsLog();
            pal->act(*this);
            actionsLog.push_back(pal);
        }
        if (arguments[0] == "close")
        {
            Close *c = new Close();
            c->act(*this);
            actionsLog.push_back(c);
        }
        if (arguments[0] == "backup")
        {
            BackupSimulation *b = new BackupSimulation();
            b->act(*this);
            actionsLog.push_back(b);
        }
        if (arguments[0] == "restore")
        {
            RestoreSimulation *r = new RestoreSimulation();
            r->act(*this);
            actionsLog.push_back(r);
        }
    }
}

void Simulation::addPlan(const Settlement *settlement, SelectionPolicy *selectionPolicy)
{
    Plan *p = new Plan(planCounter, *settlement, selectionPolicy, facilitiesOptions);
    planCounter++;
    plans.push_back(*p);
}
bool Simulation::isPlanExists(const int planID)
{
    int plansSize = plans.size();
    for (int i = 0; i < plansSize; i++)
    {
        if (plans[i].getPlanID() == planID)
        {
            return true;
        }
    }
    return false;
}
void Simulation::addAction(BaseAction *action)
{
    actionsLog.push_back(action);
}
bool Simulation::addSettlement(Settlement *settlement)
{
    if (!isSettlementExists(settlement->getName()))
    {
        settlements.push_back(settlement);
        return true;
    }
    return false;
}
bool Simulation::addFacility(FacilityType facility)
{
    if (!isFacilityExists(facility.getName()))
    {
        facilitiesOptions.push_back(facility);
        return true;
    }
    return false;
}
bool Simulation::isSelectionPolicyExists(const string &selectionPolicy)
{
    if (selectionPolicy == "nve" || selectionPolicy == "bal" || selectionPolicy == "eco")
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Simulation::isFacilityExists(const string &facilityName)
{
    int foSize = facilitiesOptions.size();
    for (int i = 0; i < foSize; i++)
    {
        if (facilitiesOptions[i].getName() == facilityName)
        {
            return true;
        }
    }
    return false;
}
bool Simulation::isSettlementExists(const string &settlementName)
{
    int settlementsSize = settlements.size();
    for (int i = 0; i < settlementsSize; i++)
    {
        if (settlements[i]->getName() == settlementName)
        {
            return true;
        }
    }
    return false;
}

Settlement *Simulation::getSettlement(const string &settlementName)
{
    int settlementsSize = settlements.size();
    for (int i = 0; i < settlementsSize; i++)
    {
        if (settlements[i]->getName() == settlementName)
        {
            return settlements[i];
        }
    }
    return nullptr;
}

Plan &Simulation::getPlan(const int planID)
{
    int plansSize = plans.size();
    bool found = false;
    int retI;
    for (int i = 0; i < plansSize && !found; i++)
    {
        if (plans[i].getPlanID() == planID)
        {
            found = true;
            retI = i;
        }
    }
    return plans[retI];
}
vector<BaseAction *> Simulation::getActionsLog() const
{
    return actionsLog;
}
void Simulation::step()
{
    for (Plan p : plans)
    {
        p.step();
    }
}
void Simulation::close()
{
    for (Plan p : plans)
    {
        cout << p.toString() << endl;
    }
    plans.clear();
    isRunning = false;
}

void Simulation::open()
{
    isRunning = true;
}
