#include "Simulation.h"
#include "Auxiliary.h"
#include <vector>
#include <algorithm>
#include <fstream>
#include <iostream>
#include "Plan.h"
using namespace std;

class Simulation {
    public:
        Simulation(const string &configFilePath){
            
            planCounter = 0;
            ifstream file(configFilePath);
            string line;
            if(file.is_open()){
                while(getline(file, line)){
                    vector<string> arguments = Auxiliary::parseArguments(line);
                    if(arguments[0]=="settlement")

                }

            }


        }
        void start();
        void addPlan(const Settlement *settlement, SelectionPolicy *selectionPolicy){
            Plan* p= new Plan(planCounter, *settlement, selectionPolicy, facilitiesOptions);
            planCounter++;
        }
        void addAction(BaseAction *action){
            actionsLog.push_back(action);
        }
        bool addSettlement(Settlement *settlement){
            if(find(settlements.begin(), settlements.end(), settlement)!=settlements.end()){
                settlements.push_back(settlement);
                return true;
            }
            return false;
           
        }
        bool addFacility(FacilityType facility){
            if(find(facilitiesOptions.begin(), facilitiesOptions.end(), facility)!=facilitiesOptions.end()){
                facilitiesOptions.push_back(facility);
                return true;
            }
            return false;
        }
        
        bool isSettlementExists(const string &settlementName){
            for(int i=0; i<settlements.size(); i++){
                if(settlements[i]->getName()==settlementName){
                    return true;
                }
            }
            return false;
        }
        Settlement *getSettlement(const string &settlementName){
            for(int i=0; i<settlements.size(); i++){
                if(settlements[i]->getName()==settlementName){
                    return settlements[i];
                }
            }
        }
        Plan &getPlan(const int planID){
            for(int i=0; i<plans.size(); i++){
                if(plans[i].getPlanID()==planID){
                    return plans[i];
                }
            }
        }
        void step(){
            for(Plan p : plans){
                if (p.getPlanStatus()==PlanStatus::AVALIABLE){
                    p.step();

            }
        }
        void close();
        void open();
      }

    private:
        bool isRunning;
        int planCounter; //For assigning unique plan IDs
        vector<BaseAction*> actionsLog;
        vector<Plan> plans;
        vector<Settlement*> settlements;
        vector<FacilityType> facilitiesOptions;
};