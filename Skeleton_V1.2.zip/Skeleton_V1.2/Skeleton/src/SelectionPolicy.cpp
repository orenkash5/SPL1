#include "SelectionPolicy.h"
#include <iostream>

using namespace std;

class NaiveSelection: public SelectionPolicy {
    public:
        NaiveSelection(){
            lastSelectedIndex = 0;
        }
        const FacilityType& selectFacility(const vector<FacilityType>& facilitiesOptions) override{
            FacilityType Ft = facilitiesOptions[lastSelectedIndex];
            lastSelectedIndex = (lastSelectedIndex + 1)%facilitiesOptions.size();
            return Ft;
        }
        const string toString() const override{return "Naive";} 

        NaiveSelection *clone() const override{
            NaiveSelection* n = new NaiveSelection();
            n->lastSelectedIndex = this->lastSelectedIndex;
            return n;
        }
        ~NaiveSelection() override = default;
    private:
        int lastSelectedIndex;
    };

class BalancedSelection: public SelectionPolicy {
    public:
        BalancedSelection(int LifeQualityScore, int EconomyScore, int EnvironmentScore) : LifeQualityScore(LifeQualityScore), EconomyScore(EconomyScore) , EnvironmentScore(EnvironmentScore){}
        const FacilityType& selectFacility(const vector<FacilityType>& facilitiesOptions) override{
            int maxDistance = 0;
            int maxDistanceI = 0;
            for(int i = 0; i<facilitiesOptions.size(); i++){
                int maxScore;
                int minScore;
                maxScore = max(LifeQualityScore + facilitiesOptions[i].getLifeQualityScore(), EconomyScore + facilitiesOptions[i].getEconomyScore());
                maxScore = max(maxScore, EnvironmentScore + facilitiesOptions[i].getEnvironmentScore());
                minScore = min(LifeQualityScore + facilitiesOptions[i].getLifeQualityScore(), EconomyScore + facilitiesOptions[i].getEconomyScore());
                minScore = min(minScore, EnvironmentScore + facilitiesOptions[i].getEnvironmentScore());
                if(maxScore - minScore>maxDistance){
                    maxDistance = maxScore-minScore;
                    maxDistanceI = i;
                }
            }
            return facilitiesOptions[maxDistanceI];
        }
        const string toString() const override{
            return "Balance";
        }
        BalancedSelection *clone() const override{
            BalancedSelection* b = new BalancedSelection(LifeQualityScore, EconomyScore, EnvironmentScore);
            return b;
        }
        ~BalancedSelection() override = default;
    private:
        int LifeQualityScore;
        int EconomyScore;
        int EnvironmentScore;
};
class EconomySelection: public SelectionPolicy {
    public:
        EconomySelection(){
            lastSelectedIndex = -1;
        }
        const FacilityType& selectFacility(const vector<FacilityType>& facilitiesOptions) override{
            bool flag=false;
            int i = lastSelectedIndex;
            while(!flag){
                i = (i+1)%facilitiesOptions.size();
                if(facilitiesOptions[i].getEconomyScore()!=0){
                    lastSelectedIndex = i;
                    flag = true;
                }
                return facilitiesOptions[lastSelectedIndex];
            }
        }
        
        const string toString() const override {
            return "Economy";
        }
        EconomySelection *clone() const override{
            EconomySelection* e= new EconomySelection();
            (*e).lastSelectedIndex=(*this).lastSelectedIndex;
            return e;
        }

        ~EconomySelection() override = default;

    private:
        int lastSelectedIndex;

};

class SustainabilitySelection: public SelectionPolicy {
    public:
        SustainabilitySelection() {
            lastSelectedIndex=0; 
        }
        const FacilityType& selectFacility(const vector<FacilityType>& facilitiesOptions) override{
            int i = lastSelectedIndex;
            bool flag=false;
            while(!flag){
                if(facilitiesOptions[i].getEnvironmentScore()!=0){
                    flag=true;
                    lastSelectedIndex= i;
                }
                else i =(i+1)%facilitiesOptions.size();
            }
        return facilitiesOptions[(lastSelectedIndex-1)%facilitiesOptions.size()];
        }
        
        const string toString() const override{
            return "Sustainability";
        }
        SustainabilitySelection *clone() const override{
            SustainabilitySelection* s= new SustainabilitySelection();
            (*s).lastSelectedIndex= (*this).lastSelectedIndex;
            return s;
        }
        
        ~SustainabilitySelection() override = default;
    private:
        int lastSelectedIndex;
};
