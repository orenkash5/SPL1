#include "Plan.h"
#include <iostream>
#include <algorithm>
using namespace std;



Plan::Plan(const int planId, const Settlement &settlement, SelectionPolicy *selectionPolicy, const vector<FacilityType> &facilityOptions)
    : plan_id(planId), settlement(&settlement), selectionPolicy(selectionPolicy), status(PlanStatus::AVALIABLE), facilities(), underConstruction(), facilityOptions(facilityOptions), life_quality_score(0), economy_score(0), environment_score(0) {}
const int Plan::getPlanID() const
{
    return plan_id;
}
Plan::Plan(const Plan &other) 
    : plan_id(other.plan_id), settlement(other.settlement), selectionPolicy(other.selectionPolicy), status(other.status), facilities(), underConstruction(), facilityOptions(other.facilityOptions), life_quality_score(other.life_quality_score), economy_score(other.economy_score), environment_score(other.environment_score)
{
    for (Facility *f : other.facilities)
    {
        facilities.push_back(new Facility(*f));
    }
    for (Facility *f : other.underConstruction)
    {
        underConstruction.push_back(new Facility(*f));
    }
}
void Plan::clear()
{
    delete settlement;
    delete selectionPolicy;
    for (Facility *f : facilities)
    {
        delete f;
    }
    facilities.clear();
    for (Facility *f : underConstruction)
    {
        delete f;
    }
    underConstruction.clear();
}
Plan::~Plan()
{
    clear();
}
Plan::Plan(Plan &&other) : plan_id(other.plan_id),
                           settlement(other.settlement),
                           selectionPolicy(other.selectionPolicy),
                           status(other.status),
                           facilities(std::move(other.facilities)),
                           underConstruction(std::move(other.underConstruction)),
                           facilityOptions(other.facilityOptions),
                           life_quality_score(other.life_quality_score),
                           economy_score(other.economy_score),
                           environment_score(other.environment_score)
{
    other.settlement = nullptr;
    other.selectionPolicy = nullptr;
    other.life_quality_score = 0;
    other.economy_score = 0;
    other.environment_score = 0;
    other.facilities.clear();
    other.underConstruction.clear();
}
const int Plan::getlifeQualityScore() const
{
    return life_quality_score;
}
const int Plan::getEconomyScore() const
{
    return economy_score;
}
const int Plan::getEnvironmentScore() const
{
    return environment_score;
}
void Plan::setSelectionPolicy(SelectionPolicy *selectionPolicy)
{
    this->selectionPolicy = selectionPolicy;
}
void Plan::step()
{
    int settlementSize = (*settlement).constructionLimit();
    while (status == PlanStatus::AVALIABLE)
    {
        FacilityType ft = (*selectionPolicy).selectFacility(facilityOptions);
        Facility *f = new Facility(ft, (*settlement).getName());
        underConstruction.push_back(f);
        int underConstructionSize = underConstruction.size();
        if (underConstructionSize == settlementSize)
        {
            status = PlanStatus::BUSY;
        }
    }
    for (Facility *f : underConstruction)
    {
        if (f->step() == FacilityStatus::OPERATIONAL)
        {
            facilities.push_back(f);
            Facility *toDelete = f;
            auto it = find(underConstruction.begin(), underConstruction.end(), toDelete);
            underConstruction.erase(it);
        }
    }
    int underConstructionSize = underConstruction.size();
    if (underConstructionSize == settlementSize)
    {
        status = PlanStatus::BUSY;
    }
    else
    {
        status = PlanStatus::AVALIABLE;
    }
}
void Plan::printStatus()
{
    cout << "Plan ID: " << plan_id << endl;
    string statusStr;
    switch (status)
    {
    case PlanStatus::AVALIABLE:
        statusStr = "AVALIABLE";
        break;
    case PlanStatus::BUSY:
        statusStr = "BUSY";
        break;
    }
    cout << "planStatus: " << statusStr << endl;
    cout << "selectionPolicy: " << selectionPolicy->toString() << endl;
    cout << "LifeQualityScore: " << life_quality_score << endl;
    cout << "EconomyScore: " << economy_score << "\n"
         << endl;
    cout << "EnvironmentScore: " << environment_score << endl;
    for (Facility *f : facilities)
    {
        cout << (*f).toString() << endl;
    }
}
const vector<Facility *> &Plan::getFacilities() const
{
    return facilities;
}
void Plan::addFacility(Facility *facility)
{
    facilities.push_back(facility);
}
const string Plan::toString() const
{
    return "Plan ID: " + to_string(plan_id) + "/n" + settlement->toString() + "/n" + "LifeQuality_Score: " + to_string(life_quality_score) + "/n" + "Economy_Score: " + to_string(economy_score) + "/n" + "Environment_Score: " + to_string(environment_score);
}
const PlanStatus Plan::getPlanStatus() const
{
    return status;
}
SelectionPolicy *Plan::getSelectionPolicy() const
{
    return selectionPolicy;
}

