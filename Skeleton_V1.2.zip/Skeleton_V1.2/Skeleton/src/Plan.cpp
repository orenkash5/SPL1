#include "Plan.h"
#include <iostream>
using namespace std;

enum class PlanStatus {
    AVALIABLE,
    BUSY,
};

class Plan{
    public: 
        Plan(const int planId, const Settlement &settlement, SelectionPolicy *selectionPolicy, const vector<FacilityType> &facilityOptions) : plan_id(planId), settlement(&settlement), selectionPolicy(selectionPolicy), facilityOptions(facilityOptions), status(PlanStatus::AVALIABLE), life_quality_score(0), economy_score(0), environment_score(0) {}
        const int getPlanID() const{
            return plan_id;
        }
        const int getlifeQualityScore() const{
            return life_quality_score;
        }
        const int getEconomyScore() const{
            return economy_score;
        }
        const int getEnvironmentScore() const{
            return environment_score;
        }
        void setSelectionPolicy(SelectionPolicy *selectionPolicy){
            this->selectionPolicy = selectionPolicy;
        }
        void step();
        void printStatus(){
            string statusStr;
            switch(status){
                case PlanStatus::AVALIABLE:
                    statusStr = "avaliable";
                    break;
                case PlanStatus::BUSY:
                    statusStr= "busy";
                    break;
            }
            cout << "Plan " << plan_id << " is " << statusStr << endl;

        }
        const vector<Facility*> &getFacilities() const{
            return facilities;
        }
        void addFacility(Facility* facility){
            facilities.push_back(facility);
        }
        const string toString() const;

        const PlanStatus getPlanStatus() const{
            return status;
        }


    private:
        int plan_id;
        const Settlement *settlement;
        SelectionPolicy *selectionPolicy; //What happens if we change this to a reference?
        PlanStatus status;
        vector<Facility*> facilities;
        vector<Facility*> underConstruction;
        const vector<FacilityType> &facilityOptions;
        int life_quality_score, economy_score, environment_score;
};

