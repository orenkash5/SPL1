#include "Settlement.h"
#include <iostream>
using namespace std;

enum class SettlementType {
    VILLAGE,
    CITY,
    METROPOLIS,
};

class Settlement{
    public:
        Settlement(const string &name, SettlementType type) : name(name), type(type){}

        const string &getName() const{
            return name;
        }
        SettlementType getType() const{
            return type;
        }
        const string toString() const{
            string settlementString;
            switch(type)
            {
                case SettlementType::VILLAGE:
                    settlementString = "Village";
                case SettlementType::CITY:
                    settlementString  = "City";
                case SettlementType::METROPOLIS:
                    settlementString = "Metropolis";
                }
            return name + " "+ settlementString;
        }
    private:
        const string name;
        SettlementType type;


};