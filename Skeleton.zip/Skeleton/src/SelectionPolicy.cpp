#include "SelectionPolicy.h"
#include <iostream>

using namespace std;

NaiveSelection::NaiveSelection(): lastSelectedIndex(0){}

const FacilityType& NaiveSelection::selectFacility(const vector<FacilityType>& facilitiesOptions) {
    const FacilityType& Ft = facilitiesOptions[lastSelectedIndex];
    lastSelectedIndex = (lastSelectedIndex + 1)%facilitiesOptions.size();
    return Ft;
}
const string NaiveSelection::toString() const{
    return "nve";
}
NaiveSelection *NaiveSelection::clone() const{
    NaiveSelection* n = new NaiveSelection();
    n->lastSelectedIndex = this->lastSelectedIndex;
    return n;
}


BalancedSelection::BalancedSelection(int LifeQualityScore, int EconomyScore, int EnvironmentScore) : LifeQualityScore(LifeQualityScore), EconomyScore(EconomyScore) , EnvironmentScore(EnvironmentScore){}
const FacilityType& BalancedSelection::selectFacility(const vector<FacilityType>& facilitiesOptions){
    int maxDistance = 0;
    int maxDistanceI = 0;
    int facilitiesOptionsSize = facilitiesOptions.size();
    for(int i = 0; i<facilitiesOptionsSize; i++){
        int maxScore;
        int minScore;
        maxScore = max(LifeQualityScore + facilitiesOptions[i].getLifeQualityScore(), EconomyScore + facilitiesOptions[i].getEconomyScore());
        maxScore = max(maxScore, EnvironmentScore + facilitiesOptions[i].getEnvironmentScore());
        minScore = min(LifeQualityScore + facilitiesOptions[i].getLifeQualityScore(), EconomyScore + facilitiesOptions[i].getEconomyScore());
        minScore = min(minScore, EnvironmentScore + facilitiesOptions[i].getEnvironmentScore());
        if(maxScore - minScore>maxDistance){
            maxDistance = maxScore-minScore;
            maxDistanceI = i;
        }
    }
    return facilitiesOptions[maxDistanceI];
}
const string BalancedSelection::toString() const{
    return "bal";
}
BalancedSelection *BalancedSelection::clone() const{
    BalancedSelection* b = new BalancedSelection(LifeQualityScore, EconomyScore, EnvironmentScore);
    return b;
}


EconomySelection::EconomySelection(): lastSelectedIndex(-1){
}
const FacilityType& EconomySelection::selectFacility(const vector<FacilityType>& facilitiesOptions){
    int facilitiesOptionsSize = facilitiesOptions.size();
    bool flag=false;
    int i = lastSelectedIndex;
    while(!flag){
        i = (i+1)%facilitiesOptionsSize;
        if(facilitiesOptions[i].getEconomyScore()!=0){
            lastSelectedIndex = i;
            flag = true;
        }
    }
    return facilitiesOptions[lastSelectedIndex];

}
const string EconomySelection::toString() const{
    return "eco";
}
EconomySelection *EconomySelection::clone() const{
    EconomySelection* e= new EconomySelection();
    (*e).lastSelectedIndex=(*this).lastSelectedIndex;
    return e;
}

SustainabilitySelection::SustainabilitySelection(): lastSelectedIndex(-1){
}
const FacilityType& SustainabilitySelection::selectFacility(const vector<FacilityType>& facilitiesOptions){
    int i = lastSelectedIndex;
    bool flag=false;
    while(!flag){
        i = (i+1)%facilitiesOptions.size();
        if(facilitiesOptions[i].getEnvironmentScore()!=0){
            flag=true;
            lastSelectedIndex= i;
        }
    }
    return facilitiesOptions[lastSelectedIndex];
}
const string SustainabilitySelection::toString() const{
    return "env";
}
SustainabilitySelection *SustainabilitySelection::clone() const{
    SustainabilitySelection* s= new SustainabilitySelection();
    (*s).lastSelectedIndex= (*this).lastSelectedIndex;
    return s;
}

