
#include "Action.h"
#include "iostream"
#include "Simulation.h"

using namespace std;

extern Simulation* backup;

enum class SettlementType;
enum class FacilityCategory;

BaseAction:: BaseAction() : errorMsg(""), status(ActionStatus::COMPLETED){}
ActionStatus BaseAction::getStatus() const{
    return status;
}

void BaseAction::complete(){
    status = ActionStatus::COMPLETED;
}

void BaseAction::error(string errorMsg){
    status = ActionStatus::ERROR;
    this->errorMsg = errorMsg;
    cerr << errorMsg << endl;
}

const string &BaseAction::getErrorMsg() const{
    return errorMsg;
}

SimulateStep::SimulateStep(const int numOfSteps) : numOfSteps(numOfSteps){}

void SimulateStep::act(Simulation &simulation){
    for(int i=0; i<numOfSteps; i++){
        simulation.step();
    }
    this->complete();
}
SimulateStep *SimulateStep::clone() const{
    SimulateStep* s = new SimulateStep(numOfSteps);
    return s;
}
const string SimulateStep::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "SimulateStep " + to_string(numOfSteps) + " " + statusString;
}


AddPlan::AddPlan(const string &settlementName, const string &selectionPolicy): settlementName(settlementName), selectionPolicy(selectionPolicy){}

void AddPlan::act(Simulation &simulation){
    if(simulation.isSettlementExists(settlementName) && simulation.isSelectionPolicyExists(selectionPolicy))
    {
        SelectionPolicy* sp;
        if(selectionPolicy == "nve"){
            sp = new NaiveSelection();
        }
        else
            if(selectionPolicy == "bal"){
                sp = new BalancedSelection(0, 0, 0);
            }
        else   
            if(selectionPolicy == "eco"){
                sp = new EconomySelection();
            }
        else
            if(selectionPolicy == "env"){
                sp = new SustainabilitySelection();
            }
        const Settlement& s = simulation.getSettlement(settlementName);
        simulation.addPlan(s, sp);
        this->complete();
    }
    else
    {
        error("Cannot create this plan");
    }
        
}
AddPlan *AddPlan::clone() const{
    AddPlan* a = new AddPlan(settlementName, selectionPolicy);
    return a;
}
const string AddPlan::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "AddPlan: " + settlementName + " " + selectionPolicy + " " + statusString;}


AddSettlement::AddSettlement(const string &settlementName, SettlementType settlementType): settlementName(settlementName), settlementType(settlementType){}
void AddSettlement::act(Simulation &simulation){
    if(!simulation.isSettlementExists(settlementName))
    {
        Settlement* s = new Settlement(settlementName, settlementType);
        simulation.addSettlement(s);
        this->complete();
    }
    else
    {
        error("Settlement already exists");
    }
}
AddSettlement *AddSettlement::clone() const{
    AddSettlement* a = new AddSettlement(settlementName, settlementType);
    return a;
}
const string AddSettlement::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    string settlementTypeString;
    switch(this->settlementType){
        case SettlementType::VILLAGE:
            settlementTypeString = "VILLAGE";
            break;
        case SettlementType::CITY:
            settlementTypeString = "CITY";
            break;
        case SettlementType::METROPOLIS:
            settlementTypeString = "METROPOLIS";
            break;
    }
    return "AddSettlement: " + settlementName + "" + settlementTypeString + " " + statusString;
}

AddFacility::AddFacility(const string &facilityName, const FacilityCategory facilityCategory, const int price, const int lifeQualityScore, const int economyScore, const int environmentScore) : facilityName(facilityName), facilityCategory(facilityCategory), price(price), lifeQualityScore(lifeQualityScore), economyScore(economyScore), environmentScore(environmentScore){}
void AddFacility::act(Simulation &simulation){
    if(!simulation.isFacilityExists(facilityName))
    {
        FacilityType f(facilityName, facilityCategory, price, lifeQualityScore, economyScore, environmentScore);
        simulation.addFacility(f);
        this->complete();
    }
    else
    {
        error("Facility already exists");
    }
}
AddFacility *AddFacility::clone() const{
    AddFacility* a = new AddFacility(facilityName, facilityCategory, price, lifeQualityScore, economyScore, environmentScore);
    return a;
}
const string AddFacility::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "AddFacility: " + facilityName + " " + to_string(price) + " " + to_string(lifeQualityScore) + " " + to_string(economyScore) + " " + to_string(environmentScore) + " " + statusString;
}

PrintPlanStatus::PrintPlanStatus(int planId): planId(planId){}
void PrintPlanStatus::act(Simulation &simulation){
    if(simulation.isPlanExists(planId))
    {
        Plan p = simulation.getPlan(planId);
        p.printStatus();
        this->complete();
    }
    else{
        error("Plan does not exist");
    }
}
PrintPlanStatus *PrintPlanStatus::clone() const{
    PrintPlanStatus* p = new PrintPlanStatus(planId);
    return p;
}
const string PrintPlanStatus::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "PrintPlanStatus " + to_string(planId) + " " + statusString;
}

ChangePlanPolicy::ChangePlanPolicy(const int planId, const string &newPolicy): planId(planId), newPolicy(newPolicy){}

void ChangePlanPolicy::act(Simulation &simulation){
    if(simulation.isPlanExists(planId)){
        Plan p = simulation.getPlan(planId);
        SelectionPolicy* current = p.getSelectionPolicy();
        if(current->toString()!=newPolicy){
            SelectionPolicy* newSelectionPolicy;
            if(newPolicy=="nve"){
                newSelectionPolicy = new NaiveSelection();
            }
            else
                if(newPolicy=="bal"){
                    newSelectionPolicy = new BalancedSelection(0, 0, 0);
                }
            else
                if(newPolicy=="eco"){
                    newSelectionPolicy = new EconomySelection();
                }
            else{
                if(newPolicy=="env"){
                    newSelectionPolicy = new SustainabilitySelection();
                }
            }
            p.setSelectionPolicy(newSelectionPolicy);
            this->complete();
        }
        else{
            error("Cannot change selection policy");
        }
    }
    else{
        error("Cannot change selection policy");
    }
}
ChangePlanPolicy *ChangePlanPolicy::clone() const{
    ChangePlanPolicy* c = new ChangePlanPolicy(planId, newPolicy);
    return c;
}
const string ChangePlanPolicy::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "ChangePlanPolicy " + to_string(planId) + " " + newPolicy + " " + statusString;
}

PrintActionsLog::PrintActionsLog(){}
void PrintActionsLog::act(Simulation &simulation){
    for (BaseAction* a : simulation.getActionsLog()){
        cout << a->toString() << endl;
    }
    this->complete();
}
PrintActionsLog *PrintActionsLog::clone() const{
    return new PrintActionsLog();
}
const string PrintActionsLog::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "PrintActionsLog " + statusString;
}

Close::Close(){}
void Close::act(Simulation &simulation){
    simulation.close();
    this->complete();
}
Close *Close::clone() const{
    Close* c = new Close();
    return c;
}
const string Close::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "Close " + statusString;
}

BackupSimulation::BackupSimulation(){}
void BackupSimulation::act(Simulation &simulation){
    if (backup!=nullptr){
        delete backup; 
        backup=nullptr;
    }
    backup= new Simulation(simulation); 
    this->complete();
}
BackupSimulation *BackupSimulation::clone() const{
    BackupSimulation* b = new BackupSimulation();
    return b;
}
const string BackupSimulation::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "Backup " + statusString;
}

RestoreSimulation::RestoreSimulation(){}
void RestoreSimulation::act(Simulation &simulation){
    if (backup!=nullptr){
        simulation=*backup;
        this->complete();
    }
    else { error("No backup available");
    }
}
RestoreSimulation *RestoreSimulation::clone() const{
    RestoreSimulation* r = new RestoreSimulation();
    return r;
}
const string RestoreSimulation::toString() const{
    string statusString;
    switch(getStatus()){
        case ActionStatus::COMPLETED:
            statusString = "COMPLETED";
            break;
        case ActionStatus::ERROR:
            statusString = "ERROR";
            break;
    }
    return "RestoreSimulation " + statusString;
}

